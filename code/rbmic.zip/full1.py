#from calculate_angle import calculate_angle_difference, update_points_after_rotation, draw_line_and_calculate_angle
#from calculate_length import calculate_line_length, resize_and_get_new_points
#from final_crop import crop_image_to_match_reference
#from overlay_image import overlay_images
import time  
import cv2
import math
import imageio
import numpy as np
import matplotlib
matplotlib.use('TkAgg')  
import matplotlib.pyplot as plt
from PIL import Image
import os
import sys
sys.setrecursionlimit(100000)

Image.MAX_IMAGE_PIXELS = None

def draw_line_and_calculate_angle(image_path, point1, point2):
    try:
        image = cv2.imread(image_path)
        cv2.circle(image, point1, 15, (0, 0, 255), -1)
        cv2.circle(image, point2, 15, (255, 0, 0), -1)
        cv2.line(image, point1, point2, (255, 0, 0), 3)

        image_with_points_and_line_path = f"output_{point1}_{point2}.jpg"
        cv2.imwrite(image_with_points_and_line_path, image)

        angle = math.degrees(math.atan2(point2[1] - point1[1], point2[0] - point1[0]))

        return image_with_points_and_line_path, angle
    except Exception as e:
        return None, None

def calculate_angle_difference(image_path1, point1, point2, image_path2, point3, point4):
    image_with_points_and_line1, angle1 = draw_line_and_calculate_angle(image_path1, point1, point2)
    image_with_points_and_line2, angle2 = draw_line_and_calculate_angle(image_path2, point3, point4)

    if image_with_points_and_line1 and angle1 is not None and image_with_points_and_line2 and angle2 is not None:
        angle_difference = angle2 - angle1
        return angle1, angle2, angle_difference
    else:
        return None, None, None

def rotate_and_update_points(image_path, angle, points, output_path):
    try:
        # Read the original image
        original_image = cv2.imread(image_path)

        # Get the image center and rotation matrix
        height, width = original_image.shape[:2]
        center = (width // 2, height // 2)
        rotation_matrix = cv2.getRotationMatrix2D(center, angle, 1.0)

        # Rotate the image
        rotated_image = cv2.warpAffine(original_image, rotation_matrix, (width, height), borderMode=cv2.BORDER_CONSTANT, borderValue=(0, 0, 0))

        # Rotate the points
        rotated_points = []
        for point in points:
            x, y = point
            new_x = rotation_matrix[0, 0] * x + rotation_matrix[0, 1] * y + rotation_matrix[0, 2]
            new_y = rotation_matrix[1, 0] * x + rotation_matrix[1, 1] * y + rotation_matrix[1, 2]
            rotated_points.append((new_x, new_y))

        # Save the rotated image
        cv2.imwrite(output_path, rotated_image)

        return rotated_points

    except Exception as e:
        print("Error:", e)
        return None


def update_points_after_rotation(image_path2, angle, original_points, output_path1):
    try:
        image = cv2.imread(image_path2)

        height, width = image.shape[:2]
        center = (width / 2, height / 2)

        rotation_matrix = cv2.getRotationMatrix2D(center, angle, 1.0)

        rotated_image = cv2.warpAffine(image, rotation_matrix, (width, height))

        rotated_points = []
        for original_point in original_points:
            x, y = original_point
            x_offset = x - center[0]
            y_offset = y - center[1]
            x_new = center[0] + x_offset * math.cos(math.radians(angle)) - y_offset * math.sin(math.radians(angle))
            y_new = center[1] + x_offset * math.sin(math.radians(angle)) + y_offset * math.cos(math.radians(angle))
            rotated_points.append((int(x_new), int(y_new)))

        rotated_image_path = output_path1
        cv2.imwrite(rotated_image_path, rotated_image)

        return rotated_points
    except Exception as e:
        return None, []

def calculate_line_length(image_path, point1, point2):
    try:
        image = cv2.imread(image_path)

        #cv2.circle(image, point1, 5, (0, 0, 255), -1)
        #cv2.circle(image, point2, 5, (255, 0, 0), -1)
        #cv2.line(image, point1, point2, (0, 255, 0), 3)

        length = math.sqrt((point2[0] - point1[0])**2 + (point2[1] - point1[1])**2)

        #image_rgb = cv2.cvtColor(image, cv2.COLOR_BGR2RGB)
        #plt.imshow(image_rgb)
        #plt.axis('off')
        #plt.show()

        return length
    except Exception as e:
        return None


def resize_and_get_new_points(image_path, resize_scale, output_path, original_points=None):
    try:
        image = cv2.imread(image_path)

        original_height, original_width = image.shape[:2]

        resized_image = cv2.resize(image, None, fx=resize_scale, fy=resize_scale, interpolation=cv2.INTER_CUBIC)

        resized_height, resized_width = resized_image.shape[:2]

        cv2.imwrite(output_path, resized_image)

        resized_points = None
        if original_points:
            resized_points = []
            for original_point in original_points:
                x, y = original_point
                x_new = int(x * resize_scale)
                y_new = int(y * resize_scale)
                resized_points.append((x_new, y_new))

        return (original_width, original_height), (resized_width, resized_height), resized_points, output_path
    except Exception as e:
        print("Error: {}".format(e))
        return None, None, None

def crop_image_to_match_reference(image_path, output_path, target_size, original_coordinate, new_coordinate):
    try:
        original_image = imageio.imread(image_path)
        image_height, image_width = original_image.shape[:2]

        left = original_coordinate[0] - new_coordinate[0]
        upper = original_coordinate[1] - new_coordinate[1]
        right = left + target_size[0]
        lower = upper + target_size[1]

        new_left = max(0, -left)
        new_upper = max(0, -upper)
        new_right = min(target_size[0], image_width - left)
        new_lower = min(target_size[1], image_height - upper)

        cropped_image = np.zeros((target_size[1], target_size[0], original_image.shape[2]), dtype=np.uint8)

        cropped_image[new_upper:new_lower, new_left:new_right] = original_image[max(upper, 0):min(lower, image_height), 
                                                                                  max(left, 0):min(right, image_width)]

        imageio.imwrite(output_path, cropped_image)

        return output_path
    except Exception as e:
        print("Error:", e)
        return None



def overlay_images(image_path1, image_path2, output_path, alpha=0.35):
    try:
        image1 = cv2.imread(image_path1)
        height1, width1 = image1.shape[:2]

        image2 = cv2.imread(image_path2)
        image2 = cv2.resize(image2, (width1, height1))

        overlay = cv2.addWeighted(image1, 1 - alpha, image2, alpha, 0)
        cv2.imwrite(output_path, overlay)

        return output_path
    except Exception as e:
        print("Error: {}".format(e))
        return None

# Get user input for paths and points
# 获取用户输入的路径和坐标点

image_path1 = input("Enter the path for the first image: ")
point1_x = int(input("Enter x coordinate for point 1: "))
point1_y = int(input("Enter y coordinate for point 1: "))
point2_x = int(input("Enter x coordinate for point 2: "))
point2_y = int(input("Enter y coordinate for point 2: "))

image_path2 = input("Enter the path for the second image: ")
point3_x = int(input("Enter x coordinate for point 3: "))
point3_y = int(input("Enter y coordinate for point 3: "))
point4_x = int(input("Enter x coordinate for point 4: "))
point4_y = int(input("Enter y coordinate for point 4: "))

point1 = (point1_x, point1_y)
point2 = (point2_x, point2_y)
point3 = (point3_x, point3_y)
point4 = (point4_x, point4_y)

# Construct output paths based on image_path2
# 根据image_path2构建输出路径

output_folder = os.path.dirname(image_path2)
output_path1 = os.path.join(output_folder, 'rotated_pic2.jpg')
output_path2 = os.path.join(output_folder, 'resized_rotated_pic2.jpg')
output_path3 = os.path.join(output_folder, 'final_cropped_pic2.jpg')
output_path4 = os.path.join(output_folder, 'overlay_pic1_pic2.jpg')

# Calculate angle difference
# 计算角度差异

angle1, angle2, angle_difference = calculate_angle_difference(image_path1, (point1_x, point1_y), (point2_x, point2_y), image_path2, (point3_x, point3_y), (point4_x, point4_y))

if angle1 is not None and angle2 is not None and angle_difference is not None:
    print(f"Angle between the line in the first image and the horizontal plane: {angle1} degrees")
    print(f"Angle between the line in the second image and the horizontal plane: {angle2} degrees")
    print(f"Difference in angle between the lines in the two images: {angle_difference} degrees")

    # Rotate the points and update
    # 旋转点并更新
    rotated_points = rotate_and_update_points(image_path2, angle_difference, [(point3_x, point3_y), (point4_x, point4_y)], output_path1)
    point5, point6 = rotate_and_update_points(image_path2, angle_difference, [(point3_x, point3_y), (point4_x, point4_y)], output_path1)

    if rotated_points:
        print("Rotated coordinates:")
        for i, point in enumerate(rotated_points, start=1):
            print(f"Point {i}: {point}")
    else:
        print("An error occurred during rotation and update of points.")
else:
    print("An error occurred during processing.")



# Calculate lengths of segments on both images
# 计算两张图片上的线段长度
len1 = calculate_line_length(image_path1, (point1_x, point1_y), (point2_x, point2_y))
len2 = calculate_line_length(output_path1, point5, point6)

if len1 is not None and len2 is not None:
    ratio = len1 / len2 if len2 != 0 else None
    if ratio is not None:
        print(f"Length of line between two points in the first image: {len1:.2f} pixels")
        print(f"Length of line between two points in the rotated second image: {len2:.2f} pixels")
        print(f"Magnification ratio of the rotated second image relative to the first image: {ratio:.2f}")
    else:
        print("Length of the rotated second image is zero, cannot compute ratio.")
else:
    print("An error occurred during processing.")

# The resize scale might need adjustment based on actual conditions
# 根据实际情况调整放缩比例
resize_scale = len1 / len2
original_points = [point5, point6]

# Resize the image and get new points
# 调整图片大小并获取新的点
original_size, resized_size, resized_points, resized_image_path = resize_and_get_new_points(output_path1, resize_scale, output_path2, original_points)
point7, point8 = resized_points

if original_size is not None and resized_size is not None and resized_image_path is not None:
    print("Original image size: {} x {}".format(original_size[0], original_size[1]))
    print("Resized image size: {} x {}".format(resized_size[0], resized_size[1]))
    print("Resized image saved at: {}".format(resized_image_path))
    print("Coordinates in the resized image:")
    for i, point in enumerate(resized_points, start=1):
        print(f"Point {i}: {point}")
else:
    print("An error occurred during processing.")

# Crop the image
# 裁剪图片
image_path = output_path2
target_size = original_size  # Updated to the size of img1
original_coordinate = point7  # Updated to the coordinates of pt7
new_coordinate = (point1_x, point1_y)  # Updated to the coordinates of pt1

result_image_path = crop_image_to_match_reference(image_path, output_path3, target_size, original_coordinate, new_coordinate)

if result_image_path:
    print(f"Cropped image saved at: {result_image_path}")
else:
    print("Error occurred during cropping.")

# Overlay images
# 叠加图片
image_path1 = image_path1
image_path2 = output_path3

# Specify output path for the overlay result
# 指定叠加结果的输出路径
#output_path4 = 'overlay_he_pax3.jpg'

# Perform image overlay and save
result_path = overlay_images(image_path1, output_path3, output_path4)

if result_path:
    print("Overlay image saved at: {}".format(result_path))

    # Display the overlaid image
    overlay_image = cv2.imread(result_path)
    overlay_image_rgb = cv2.cvtColor(overlay_image, cv2.COLOR_BGR2RGB)
    plt.imshow(overlay_image_rgb)
    plt.axis('off')
    plt.show()
else:
    print("An error occurred during processing.")





