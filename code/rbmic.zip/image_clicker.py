import matplotlib
matplotlib.use('TkAgg')  # 或者尝试其他后端，比如 'Qt5Agg', 'agg', 等等
import matplotlib.pyplot as plt
from PIL import Image

Image.MAX_IMAGE_PIXELS = None

class ImageClicker:
    def __init__(self, image_path):
        self.image_path = image_path
        self.image = plt.imread(image_path)
        self.points = []
        self.fig, self.ax = plt.subplots()
        self.ax.imshow(self.image)

        self.click_cid = self.fig.canvas.mpl_connect('button_press_event', self.on_click)

    def on_click(self, event):
        if event.xdata is not None and event.ydata is not None:
            x, y = int(event.xdata), int(event.ydata)
            self.points.append((x, y))
            print(f"Clicked at coordinates on the original image: ({x}, {y})")

    def save_cropped_image(self, output_path):
        if len(self.points) == 2:
            x1, y1 = self.points[0]
            x2, y2 = self.points[1]
            cropped = self.image[min(y1, y2):max(y1, y2), min(x1, x2):max(x1, x2)]
            im = Image.fromarray((cropped * 255).astype('uint8'))
            im.save(output_path)

    def run(self):
        plt.show()

if __name__ == "__main__":
    image_path = input("Enter the image path: ")
    clicker = ImageClicker(image_path)
    clicker.run()

    save = input("Do you want to save a cropped area? (yes/no): ")
    if save.lower() == 'yes':
        output_path = input("Enter the output path for the cropped image (including filename and .tiff extension): ")
        clicker.save_cropped_image(output_path)

