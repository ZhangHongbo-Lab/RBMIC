import cv2
if cv2.__version__.startswith('4.'):  # Assuming OpenCV 4.x
    cv2.gapi = None
    cv2.gapi_wip = None

import matplotlib
matplotlib.use('TkAgg')  
import matplotlib.pyplot as plt
import os

def resize_image(image, scale_factor):
    # Resize the image based on the scale factor
    resized_image = cv2.resize(image, None, fx=scale_factor, fy=scale_factor, interpolation=cv2.INTER_LINEAR)
    return resized_image

def crop_image_with_offset(image, center_x, center_y, offset_x, offset_y, crop_width, crop_height):
    # Calculate the coordinates for cropping the image based on center and offsets
    crop_x = int(center_x - crop_width // 2 + offset_x)
    crop_y = int(center_y - crop_height // 2 + offset_y)
    
    # Crop the image
    cropped_image = image[crop_y:crop_y+crop_height, crop_x:crop_x+crop_width, :]
    
    return cropped_image

def main():
    # Prompt user to enter image paths
    image_paths = input("Enter image paths (separated by space): ").split()

    # Read and get dimensions of the images
    image_sizes = []
    for path in image_paths:
        image = cv2.imread(path)
        if image is None:
            print(f"Error: Unable to read image at '{path}'. Please check the file path.")
            return

        height, width, _ = image.shape
        image_sizes.append((height, width))
        print(f"Original image at '{path}' has dimensions: {width}x{height}")

    # Prompt user to enter a single scale factor for both width and height for image 1
    scale_factor_img1 = float(input("Enter the scale factor for Image 1 (press Enter for default 1.0): ") or 1.0)

    # Resize only Image 1
    resized_image = resize_image(cv2.imread(image_paths[0]), scale_factor_img1)

    # Save resized image with prefix 'fs'
    output_path = os.path.join(os.path.dirname(image_paths[0]), f'fs_{os.path.basename(image_paths[0])}')
    cv2.imwrite(output_path, resized_image)

    # Output resized image dimensions
    resized_height, resized_width, _ = resized_image.shape
    print(f"Resized image at '{output_path}' has dimensions: {resized_width}x{resized_height}")

    # Output dimensions for Image 2
    original_height, original_width = image_sizes[1]
    print(f"Original image at '{image_paths[1]}' has dimensions: {original_width}x{original_height}")

    # Choose the minimum dimensions after resizing for Image 1 and original dimensions for Image 2
    min_resized_width = min(resized_width, original_width)
    min_resized_height = min(resized_height, original_height)

    # Output minimum dimensions after resizing for Image 1 and original dimensions for Image 2
    print(f"Minimum dimensions after resizing for Image 1 and original dimensions for Image 2: {min_resized_width}x{min_resized_height}")

    # Prompt user to enter offset values for each image, with default values set to 0
    offset_x_values = [int(val) if val else 0 for val in input("Enter horizontal offsets (separated by space, press Enter for default 0): ").split()]
    offset_y_values = [int(val) if val else 0 for val in input("Enter vertical offsets (separated by space, press Enter for default 0): ").split()]

    # Check if the number of images matches the number of offset values provided
    if len(image_paths) != len(offset_x_values) or len(image_paths) != len(offset_y_values):
        print("Error: Number of images should match the number of offset values provided.")
        return

    # Crop and visualize images
    for i, path in enumerate(image_paths):
        # Use resized image for Image 1 and original image for Image 2
        if i == 0:
            image = resized_image
        else:
            image = cv2.imread(path)

        if image is None:
            print(f"Error: Unable to read image at '{path}'. Please check the file path.")
            return

        center_x = image.shape[1] // 2
        center_y = image.shape[0] // 2

        # Use the corresponding offset values for each image
        offset_x = offset_x_values[i]
        offset_y = offset_y_values[i]

        # Use the minimum dimensions after resizing for cropping for Image 1 and original dimensions for Image 2
        cropped_image = crop_image_with_offset(image, center_x, center_y, offset_x, offset_y, min_resized_width, min_resized_height)

        output_path = os.path.join(os.path.dirname(path), f'ok_{os.path.basename(path)}')
        cv2.imwrite(output_path, cropped_image)

        plt.subplot(1, len(image_paths), i + 1)
        plt.imshow(cv2.cvtColor(cropped_image, cv2.COLOR_BGR2RGB))
        plt.title(f"Cropped Image {i + 1}")
        plt.axis('off')

    plt.show()

if __name__ == "__main__":
    main()
