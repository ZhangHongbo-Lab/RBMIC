import cv2
import numpy as np
import matplotlib
matplotlib.use('TkAgg')  
import matplotlib.pyplot as plt
import os

def get_image_path(prompt):
    return input(prompt)

def get_points(prompt):
    points = []
    print(prompt)
    for i in range(4):
        x = float(input(f"Enter x coordinate for point {i+1}: "))
        y = float(input(f"Enter y coordinate for point {i+1}: "))
        points.append([x, y])
    return np.array(points, dtype=np.float32)

def overlay_images(image_path1, image_path2, output_path, alpha=0.65):
    try:
        # Read image one
        image1 = cv2.imread(image_path1)
        height1, width1 = image1.shape[:2]

        # Read image two and resize
        image2 = cv2.imread(image_path2)
        image2 = cv2.resize(image2, (width1, height1))

        # Overlay image two onto image one and blend
        overlay = cv2.addWeighted(image1, 1 - alpha, image2, alpha, 0)

        # Save the overlaid image
        cv2.imwrite(output_path, overlay)

        return output_path
    except Exception as e:
        print("Error: {}".format(e))
        return None

if __name__ == "__main__":
    original_image_path = get_image_path("Enter the path for the original image: ")
    target_image_path = get_image_path("Enter the path for the target image: ")

    # Read the original and target images
    original_image = cv2.imread(original_image_path)
    target_image = cv2.imread(target_image_path)

    original_points = get_points("Enter coordinates for the original image points:")
    target_points = get_points("Enter coordinates for the target image points:")

    # Calculate the perspective transformation matrix
    M = cv2.getPerspectiveTransform(original_points, target_points)

    # Apply the perspective transformation
    distorted_image = cv2.warpPerspective(original_image, M, (target_image.shape[1], target_image.shape[0]))

    # Save the distorted image after perspective transformation
    cv2.imwrite('distorted_image.jpg', distorted_image)

    # Build the output path
    output_folder = os.path.dirname(original_image_path)
    output_overlay_path = os.path.join(output_folder, 'output_overlay.jpg')

    # Overlay images and save
    result_path = overlay_images('distorted_image.jpg', target_image_path, output_overlay_path)

    if result_path:
        print("Overlay result saved at: {}".format(result_path))

        # Display the overlaid image
        overlay_image = cv2.imread(result_path)
        overlay_image_rgb = cv2.cvtColor(overlay_image, cv2.COLOR_BGR2RGB)
        plt.imshow(overlay_image_rgb)
        plt.axis('off')
        plt.show()
    else:
        print("An error occurred during processing.")

